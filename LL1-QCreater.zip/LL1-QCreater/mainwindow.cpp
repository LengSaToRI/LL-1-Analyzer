#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QMessageBox>
#include <windows.h>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("LL1语法分析器");
    ui->pushButton->setIcon(QIcon(":/icon1.png"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

struct WordType
{
    int code;   //元素的编号
    QString pro; //元素的值
};
WordType get_w();

QString codestring[24] = {"System","Version","Code","Data",
                          "<",">","</","<!","!>",
                          "@@","#","//","::","=",
                          ".","/@","%","$",":",
                          "*","'","-",",",":="};
QChar ch;
QString allstack[100],info,str;
int flag=0,times=0;
int num=0;
WordType get_w();
void GetChar();
void GetBC();
bool IsLetter(QChar c);
bool IsDigit(QChar c);
void Retract();
int Reserve(QString str);
QString Concat(QString str);

WordType get_w()    //词法分析
{
    QString strToken = "";
    QString temp = "";
    int code;
    WordType wordtmp;
    GetChar();
    GetBC();
    if (IsLetter(ch))
    {
        while (IsLetter(ch) || IsDigit(ch))
        {
            strToken = Concat(strToken);
            GetChar();
        }
        Retract();
        code = Reserve(strToken);
        if (code!=0)
        {
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
        else
        {
            wordtmp.code = 100;
            wordtmp.pro = strToken;
        }
    }

    else if (IsDigit(ch))
    {
        int count = 0;
        while (IsDigit(ch) && count <=1 )
        {
            strToken = Concat(strToken);
            GetChar();
            if (ch == '.' && count <1 )
            {
                count += 1;
                temp = strToken;
                strToken = Concat(strToken);
                GetChar();
                if (!IsDigit(ch))
                {
                    strToken = temp;
                    ch = '.';
                }
            }
        }
        Retract();
        wordtmp.code = 100;
        wordtmp.pro = strToken;
    }

    else if (ch == '<')
    {
        strToken = Concat(strToken);
        GetChar();
        if (ch == '/' || ch == '!') {
            strToken = Concat(strToken);
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
        else
        {
            Retract();
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
    }

    else if (ch == ':')
    {
        strToken = Concat(strToken);
        GetChar();
        if (ch == ':' || ch =='=')
        {
            strToken = Concat(strToken);
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
        else {
            Retract();
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
    }

    else if (ch == '!')
    {
        strToken = Concat(strToken);
        GetChar();
        if (ch == '>')
        {
            strToken = Concat(strToken);
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
        else
        {
            Retract();
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
    }

    else if (ch == '/') {
        strToken = Concat(strToken);
        GetChar();
        if (ch == '/'|| ch == '@') {
            strToken = Concat(strToken);
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
        else
        {
            Retract();
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
    }

    else if (ch == '@') {
        strToken = Concat(strToken);
        GetChar();
        if (ch == '@')
        {
            strToken = Concat(strToken);
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
        else
        {
            Retract();
            code = Reserve(strToken);
            wordtmp.code = code;
            wordtmp.pro = strToken;
        }
    }

    else if (ch == '>')  { wordtmp.code = 6; wordtmp.pro = '>'; }
    else if (ch == '#')  { wordtmp.code = 11; wordtmp.pro = '#'; }
    else if (ch == '=')  { wordtmp.code = 14; wordtmp.pro = '='; }
    else if (ch == '%')  { wordtmp.code = 17; wordtmp.pro = '%'; }
    else if (ch == '$')  { wordtmp.code = 18; wordtmp.pro = '$'; }
    else if (ch == ':')  { wordtmp.code = 19; wordtmp.pro = ':'; }
    else if (ch == '*')  { wordtmp.code = 20; wordtmp.pro = '*'; }
    else if (ch == '\'') { wordtmp.code = 21; wordtmp.pro = '\''; }
    else if (ch == '-')  { wordtmp.code = 22; wordtmp.pro = '-'; }
    else if (ch == ',')  { wordtmp.code = 23; wordtmp.pro = ','; }
    else                 { wordtmp.code = 100; wordtmp.pro = ch; }
    return wordtmp;
}

void GetChar()  //读字符
{
    if (flag == 0)
    {
        ch = str[num];
        num++;
    }
    else
        flag = 0;
}

void GetBC()    //空格回车
{
    if (ch == ' ' || ch == '\n' || ch == '\t')
    {
        {
            ch = str[num];
            num++;
        }
    }
}

bool IsLetter(QChar c)   //自定义字符
{
    if (c >= 'a' && c <= 'z')
    {
        return true;
    }
    if (c >= 'A' && c <= 'Z')
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool IsDigit(QChar c)
{
    if (c >= '0' && c <= '9')
    {
        return true;
    }
    else
    {
        return false;
    }
}

QString Concat(QString str){
    QString c;
    c.push_back(ch);
    str += c;
    return str;
}

void Retract() {
    flag = 1;
}

int Reserve(QString str) {
    for (int i = 0; i < 24; i++)
    {
        if (!str.compare(codestring[i]))
            return i+1;
    }
    return 0;
}
class Stack
{
    int i;
    QString *data;
public:
    Stack();
    int push(QString m);
    int pop();
    QString getTop();
    ~Stack();
    int topNumber();
    void outStack();
    void pushReverse(QString m);
};

Stack::Stack()
{
    i = 0;
    data = new QString[100]; // 假设栈的最大容量为100
}

// 入栈操作
int Stack::push(QString m)
{
    if (i < 100)
    {
        data[i++] = m;
        return 1; // 表示入栈成功
    }
    else
    {
        return -1; // 表示栈已满，入栈失败
    }
}

// 出栈操作
int Stack::pop()
{
    if (i > 0)
    {
        i--;
        return 1; // 表示出栈成功
    }
    else
    {
        return -1; // 表示栈为空，出栈失败
    }
}

// 获取栈顶元素
QString Stack::getTop()
{
    if (i > 0)
    {
        return data[i - 1];
    }
    else
    {
        return ""; // 表示栈为空
    }
}

// 析构函数
Stack::~Stack()
{
    delete[] data;
}

// 返回当前栈中元素个数
int Stack::topNumber()
{
    return i;
}

// 输出栈中所有元素
void Stack::outStack()
{
    for (int j = 0; j <i; j++)
    {
        allstack[j]=data[j];
    }
}
void Stack::pushReverse(QString m)
{
    // 将字符串m反向入栈
    int len = m.length();
    if (m == "System") // 如果关键字是System，则按顺序压入
    {
        push("System");
        return;
    }
    else if (m == "Version")
    {
        push("Version");
        return;
    }
    else if (m == "Code")
    {
        push("Code");
        return;
    }
    else if (m == "Data")
    {
        push("Data");
        return;
    }
    for (int i = len - 1; i >= 0; )
    {
        QString c;
        c=m[i];
        i--;
        if (i >= 0)
        {
            QString d = m[i] + c;
            for (int j = 0; j < 24; j++)
            {
                if (d == codestring[j])
                {
                    c = d;
                    i--;
                    break;
                }
            }
        }
        push(c);
    }
}

class Table
{
    int row_num,line_num;
    QString rowName[10];
    int lineName[14];
    QString tableData[10][14];
public:
    Table();
    QString getCell(QString rowN,int lineN);
    int getRowNumber(QString rowN);
    int getLineNumber(int lineN);
};

Table::Table()
{
    row_num=10;
    line_num=14;

    rowName[0]="S";
    rowName[1]="A";
    rowName[2]="F";
    rowName[3]="G";
    rowName[4]="P";
    rowName[5]="B";
    rowName[6]="E";
    rowName[7]="C";
    rowName[8]="D";
    rowName[9]="H";

    lineName[0]=8;
    lineName[1]=9;
    lineName[2]=14;
    lineName[3]=1;
    lineName[4]=2;
    lineName[5]=3;
    lineName[6]=4;
    lineName[7]=100;
    lineName[8]=5;
    lineName[9]=6;
    lineName[10]=7;
    lineName[11]=13;
    lineName[12]=10;
    lineName[13]=11;



    for (int i=0;i<10;i++)
        for(int j=0;j<14;j++)
            tableData[i][j]="";

    tableData[0][0]="ABCDE";

    tableData[1][0]="<!F!>";

    tableData[2][1]="Ɛ";

    tableData[2][3]="G=PF";
    tableData[2][4]="G=PF";
    tableData[2][5]="G=PF";
    tableData[2][6]="G=PF";

    tableData[3][3]="System";
    tableData[3][4]="Version";
    tableData[3][5]="Code";
    tableData[3][6]="Data";

    tableData[4][7]="i";

    tableData[5][8]="<P::P>";

    tableData[6][10]="</P::P>";

    tableData[7][12]="@@H";

    tableData[8][10]="Ɛ";
    tableData[8][13]="#HD";

    tableData[9][7]="PH";
    tableData[9][10]="Ɛ";
    tableData[9][13]="Ɛ";
}

QString Table::getCell(QString rowN, int lineN)
{
    int row_idx = getRowNumber(rowN);
    return tableData[row_idx][lineN];
}

// 获取指定行名所在的行号
int Table::getRowNumber(QString rowN)
{
    for (int i = 0; i < row_num; i++)
    {
        if (rowName[i] == rowN)
        {
            return i;
        }
    }

    return -1; // 返回-1表示未找到对应行名
}

// 获取指定列名所在的列号
int Table::getLineNumber(int lineN)
{
    for (int i = 0; i < line_num; i++)
    {
        if (lineName[i] == lineN)
        {
            return i;
        }
    }

    return -1; // 返回-1表示未找到对应列名
}
void MainWindow::process()
{
    int stepNum=1;
    QString topStr;
    Stack stack;
    WordType word;
    Table table;
    word=get_w();
    stack.push("&");
    stack.push("S");

    while(1)
    {
        topStr=stack.getTop();

        if (stepNum>200)
        {
            break;
        }
        else if(topStr=="&"&&word.pro=="&")
        {
            info=QString::number(stepNum++);
            info+="\t";
            stack.outStack();
            for(int i=0;i<100;i++)
            {
                info+=allstack[i];
            }
            info+="\t\t";
            info+=word.pro;
            info+="\t\t";
            info+="分析完成";
            info+="\n";
            ui->listWidget->addItem(info);
            ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
            ui->pushButton->setIcon(QIcon(":/icon2.png"));
            break;
        }
        else if(topStr=="i"&&(word.code==100))
        {
            info=QString::number(stepNum++);
            info+="\t";
            stack.outStack();
            for(int i=0;i<100;i++)
            {
                info+=allstack[i];
            }
            info+="\t\t";
            info+=word.pro;
            info+="\t\t";
            info+="匹配标识符";
            info+="\n";
            ui->listWidget->addItem(info);
            ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
            stack.pop();
            word=get_w();
            Sleep(50);
            qApp->processEvents();
        }
        else if(topStr==word.pro)
        {
            info=QString::number(stepNum++);
            info+="\t";
            stack.outStack();

            for(int i=0;i<100;i++)
            {
                info+=allstack[i];
            }

            info+="\t\t";
            info+=word.pro;
            info+="\t\t";
            info+="匹配符号";
            info+="\n";
            ui->listWidget->addItem(info);
            ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
            stack.pop();
            word=get_w();
            Sleep(50);
            qApp->processEvents();
        }

        else if(table.getRowNumber(topStr)!=-1)
        {
            info=QString::number(stepNum++);
            info+="\t";
            stack.outStack();

            for(int i=0;i<100;i++)
            {
                info+=allstack[i];
            }
            int lineNum=table.getLineNumber(word.code);
            QString a=table.getCell(topStr,lineNum);
            info+="\t\t";
            info+=word.pro;
            info+="\t\t";
            info+=a;
            info+="\n";
            ui->listWidget->addItem(info);
            ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
            stack.pop();
            if(a!="Ɛ")
            {
                stack.pushReverse(a);
            }
            Sleep(50);
            qApp->processEvents();

        }
        else
        {
            ui->pushButton->setIcon(QIcon(":/icon3.png"));
            return;
        }
        for(int i=0;i<100;i++)
        {
            allstack[i]="";
        }
    }
}
void MainWindow::on_transformButton_clicked()
{
    if (times==0)
    {
        str=ui->showFrom->toPlainText();
        if(str=="")
        {
            QMessageBox::information(this,QString("提示"),QString("程序输入框不能为空"));
        }
        else
        {
            str+="&";
            qDebug()<<str;
            info="步骤";
            info+="\t";
            info+="符号栈";
            info+="\t\t";
            info+="当前单词";
            info+="\t\t";
            info+="动作";
            info+="\n";
            ui->listWidget->addItem(info);
            ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
            process();
            times++;
        }
    }
    else if (times!=0)
    {
        QMessageBox::information(this,QString("提示"),QString("请点击清除再使用"));
    }
}


void MainWindow::on_pushButton_clicked()
{
    times=0;
    num=0;
    ui->listWidget->clear();
    ui->showFrom->clear();
}





void MainWindow::on_pushButton_2_clicked()
{
    exit(0);
}


void MainWindow::on_ll1Button_clicked()
{
    QString a="S->ABCDE\n";
    a+="A-><!F!>\n";
    a+="F->G=PF|Ɛ";
    a+="G->System|Version|Code|Data\n";
    a+="P->0|...|Z\n";
    a+="B-><P::P>\n";
    a+="E-></P::P>\n";
    a+="C->@@H\n";
    a+="D->#HD|Ɛ\n";
    a+="H->PH|Ɛ";

    QMessageBox::about(this,QString("LL(1)文法"),QString(a));
}

void MainWindow::on_firstButton_clicked()
{
    QString a="first(S)={ <! }\n";
    a+="first(A)={ <! }\n";
    a+="first(F)={ S | V | C | D }\n";
    a+="first(G)={ S | V | C | D }\n";
    a+="first(P)={ 0 | ... | Z }\n";
    a+="first(B)={ < }\n";
    a+="first(E)={ </ }\n";
    a+="first(C)={ @@ }\n";
    a+="first(D)={ # }\n";
    a+="first(H)={ 0 | ... | Z }";

    QMessageBox::about(this,QString("Follow集"),QString(a));
}

void MainWindow::on_followButton_clicked()
{
    QString a="follow(S)={ & }\n";
    a+="follow(A)={ < , & }\n";
    a+="follow(F)={ !> }\n";
    a+="follow(G)={ = }\n";
    a+="follow(P)={ :: , > , S ,V ,C ,D , !> }\n";
    a+="follow(B)={ @@ , & }\n";
    a+="follow(E)={ & }\n";
    a+="follow(C)={ #, & }\n";
    a+="follow(D)={ </ , & }\n";
    a+="follow(H)={ #, </ , & }";

    QMessageBox::about(this,QString("Follow集"),QString(a));
}

void MainWindow::on_pushButton_pressed()
{
    ui->pushButton->setIcon(QIcon(":/icon5.png"));
}


void MainWindow::on_pushButton_released()
{
    ui->pushButton->setIcon(QIcon(":/icon1.png"));
}


void MainWindow::on_infoButton_clicked()
{
    QMessageBox::information(this,QString("提示"),QString("本程序由孙浩洋&张卫君制作"));
}

